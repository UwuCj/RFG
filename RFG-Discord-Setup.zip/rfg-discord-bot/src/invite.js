require('dotenv').config();
const { PermissionsBitField } = require('discord.js');

if (!process.env.CLIENT_ID) {
  console.error('Missing CLIENT_ID in .env');
  process.exit(1);
}

const F = PermissionsBitField.Flags;
const permissions = new PermissionsBitField([
  F.ViewChannel,
  F.SendMessages,
  F.EmbedLinks,
  F.AttachFiles,
  F.ReadMessageHistory,
  F.ManageRoles,
  F.ManageChannels,
  F.ManageMessages,
  F.ManageThreads,
  F.Connect,
  F.Speak,
]).bitfield.toString();

const url = `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(process.env.CLIENT_ID)}&permissions=${permissions}&scope=bot%20applications.commands`;
console.log('\nRFG Bot Invite URL:\n');
console.log(url);
console.log('\nImportant: after inviting, keep the bot role ABOVE the roles it manages.\n');
