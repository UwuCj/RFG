const {
  ChannelType,
  EmbedBuilder,
  PermissionsBitField,
} = require('discord.js');
const { roles, staffRoleKeys, brand, P } = require('./config');
const { closeTicketRow } = require('./panels');

const roleByKey = Object.fromEntries(roles.map(r => [r.key, r]));

async function toggleRole(interaction, key) {
  const def = roleByKey[key];
  if (!def) return interaction.reply({ content: 'That role is no longer configured.', ephemeral: true });
  const role = interaction.guild.roles.cache.find(r => r.name === def.name);
  if (!role) return interaction.reply({ content: 'That role has not been created yet. Ask an admin to run `/setup-rfg`.', ephemeral: true });
  if (!role.editable) return interaction.reply({ content: 'I cannot manage that role. Move the RFG bot role above the self-assign roles.', ephemeral: true });

  const has = interaction.member.roles.cache.has(role.id);
  if (has) {
    await interaction.member.roles.remove(role, 'RFG self-role toggle');
    return interaction.reply({ content: `Removed **${role.name}**.`, ephemeral: true });
  }
  await interaction.member.roles.add(role, 'RFG self-role toggle');
  return interaction.reply({ content: `Added **${role.name}**.`, ephemeral: true });
}

function staffRoles(guild) {
  return staffRoleKeys
    .map(key => guild.roles.cache.find(r => r.name === roleByKey[key]?.name))
    .filter(Boolean);
}

async function openTicket(interaction, kind) {
  const guild = interaction.guild;
  const category = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === '━━━ 🎫 SUPPORT ━━━');
  if (!category) return interaction.reply({ content: 'Support has not been configured yet. Ask an admin to run `/setup-rfg`.', ephemeral: true });

  const existing = guild.channels.cache.find(c => c.parentId === category.id && c.topic?.includes(`ticket-owner:${interaction.user.id}`));
  if (existing) return interaction.reply({ content: `You already have an open ticket: ${existing}`, ephemeral: true });

  await interaction.deferReply({ ephemeral: true });
  const safe = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 18) || 'member';
  const prefix = kind === 'report' ? 'report' : 'support';
  const overwrites = [
    { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
    { id: interaction.user.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks] },
    ...staffRoles(guild).map(role => ({ id: role.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.ManageMessages] })),
  ];

  const ch = await guild.channels.create({
    name: `${prefix}-${safe}`.slice(0, 95),
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `RFG ${prefix} ticket • ticket-owner:${interaction.user.id}`,
    permissionOverwrites: overwrites,
    reason: `Ticket opened by ${interaction.user.tag}`,
  });

  await ch.send({
    content: `${interaction.user}`,
    embeds: [new EmbedBuilder()
      .setColor(kind === 'report' ? brand.danger : brand.accent)
      .setTitle(kind === 'report' ? '🚨 Private Player Report' : '🎫 Support Ticket')
      .setDescription(
        kind === 'report'
          ? 'Tell staff what happened. Include the player name, approximate time, evidence, and any useful context. Do not post private information that is unrelated to the report.'
          : 'Describe what you need help with and include any screenshots or details that make the issue easier to understand.'
      )
      .setFooter({ text: `Opened by ${interaction.user.tag}` })],
    components: [closeTicketRow()],
  });

  const log = guild.channels.cache.find(c => c.name === 'ticket-log');
  if (log?.isTextBased()) await log.send(`🟢 ${ch} opened by ${interaction.user.tag} (${interaction.user.id}) • ${prefix}`).catch(() => {});
  return interaction.editReply({ content: `Created your private ticket: ${ch}` });
}

async function closeTicket(interaction) {
  const channel = interaction.channel;
  const ownerMatch = channel.topic?.match(/ticket-owner:(\d+)/);
  if (!ownerMatch) return interaction.reply({ content: 'This is not a RFG ticket channel.', ephemeral: true });

  const isOwner = interaction.user.id === ownerMatch[1];
  const isStaff = staffRoles(interaction.guild).some(role => interaction.member.roles.cache.has(role.id));
  if (!isOwner && !isStaff) return interaction.reply({ content: 'Only the ticket owner or staff can close this ticket.', ephemeral: true });

  await interaction.reply({ content: '🔒 Closing this ticket…' });
  const log = interaction.guild.channels.cache.find(c => c.name === 'ticket-log');
  if (log?.isTextBased()) await log.send(`🔴 #${channel.name} closed by ${interaction.user.tag} (${interaction.user.id})`).catch(() => {});
  setTimeout(() => channel.delete(`Ticket closed by ${interaction.user.tag}`).catch(() => {}), 1500);
}

async function handleButton(interaction) {
  if (interaction.customId.startsWith('role:')) return toggleRole(interaction, interaction.customId.slice(5));
  if (interaction.customId === 'ticket:support') return openTicket(interaction, 'support');
  if (interaction.customId === 'ticket:report') return openTicket(interaction, 'report');
  if (interaction.customId === 'ticket:close') return closeTicket(interaction);
}

module.exports = { handleButton };
