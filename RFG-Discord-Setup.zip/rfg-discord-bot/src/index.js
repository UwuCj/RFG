require('dotenv').config();
const {
  Client,
  GatewayIntentBits,
  PermissionFlagsBits,
  SlashCommandBuilder,
  EmbedBuilder,
} = require('discord.js');
const { setupRFG } = require('./setup');
const { handleButton } = require('./interactions');
const { brand, roles } = require('./config');

const required = ['BOT_TOKEN', 'CLIENT_ID', 'GUILD_ID'];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(', ')}`);
  console.error('Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName('setup-rfg')
    .setDescription('Build or sync the complete RFG Discord server layout.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('setup-preview')
    .setDescription('Preview what the RFG installer creates.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('setup-status')
    .setDescription('Check whether core RFG roles/channels exist.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map(c => c.toJSON());

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const guild = await client.guilds.fetch(process.env.GUILD_ID).catch(() => null);
  if (!guild) {
    console.error('Could not access GUILD_ID. Make sure the bot is invited to that server and the ID is correct.');
    return;
  }
  await guild.commands.set(commands);
  console.log(`Registered RFG setup commands in: ${guild.name}`);
  console.log('Run /setup-preview, then /setup-rfg in your server.');
});

client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isButton()) return await handleButton(interaction);
    if (!interaction.isChatInputCommand()) return;
    if (interaction.guildId !== process.env.GUILD_ID) {
      return interaction.reply({ content: 'This RFG installer is locked to the configured server.', ephemeral: true });
    }

    if (interaction.commandName === 'setup-preview') {
      const embed = new EmbedBuilder()
        .setColor(brand.accent)
        .setTitle('⚔️ RFG Server Installer')
        .setDescription(
          '**Creates/syncs:**\n' +
          `• ${roles.length} polished team, community, lane, region, and notification roles\n` +
          '• Start Here, Community, Competitive, Feedback, Voice, Playtesting, Support, Development, and Staff sections\n' +
          '• Private permission boundaries for staff/dev/testers\n' +
          '• Self-assign lane/region/ping buttons\n' +
          '• Private support + player-report tickets\n' +
          '• Welcome, rules, FAQ, announcement, and patch-note starter panels\n' +
          '• Branded webhook channel headers with custom banner art (when Manage Webhooks is available)\n' +
          '• Forum-style areas for bugs, suggestions, guides, LFG, QA, and task tracking\n\n' +
          '**Safe to re-run:** it looks up existing RFG names and syncs them instead of intentionally duplicating everything. It does not delete unrelated channels or roles.'
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.commandName === 'setup-status') {
      await interaction.guild.roles.fetch();
      await interaction.guild.channels.fetch();
      const expectedChannels = ['welcome', 'rules', 'general', 'roles', 'support', 'dev-chat', 'staff-hq'];
      const roleHits = roles.filter(def => interaction.guild.roles.cache.some(r => r.name === def.name)).length;
      const channelHits = expectedChannels.filter(name => interaction.guild.channels.cache.some(c => c.name === name)).length;
      return interaction.reply({
        content: `RFG status: **${roleHits}/${roles.length} roles** found, **${channelHits}/${expectedChannels.length} core channels** found.`,
        ephemeral: true,
      });
    }

    if (interaction.commandName === 'setup-rfg') {
      await interaction.deferReply({ ephemeral: true });
      const result = await setupRFG(interaction.guild, interaction.user.id);
      return interaction.editReply({
        content: `✅ **RFG setup complete.** Synced ${result.roleCount} roles and the full server layout.\n\nNext: move the **RFG bot role to the top of the roles it manages**, review the private staff/dev/tester access, and if you want the branded webhook headers make sure the bot also has **Manage Webhooks**. Then enable Discord Community + Onboarding if you want Discord's native onboarding flow.`,
      });
    }
  } catch (error) {
    console.error(error);
    const message = `❌ Setup error: ${error.message}`;
    if (interaction.deferred || interaction.replied) return interaction.editReply({ content: message }).catch(() => {});
    return interaction.reply({ content: message, ephemeral: true }).catch(() => {});
  }
});

client.login(process.env.BOT_TOKEN);
