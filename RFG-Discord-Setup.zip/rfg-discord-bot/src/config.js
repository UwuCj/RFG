const { PermissionsBitField } = require('discord.js');

const P = PermissionsBitField.Flags;

const brand = {
  name: 'RFG',
  accent: 0x8B5CF6,
  cyan: 0x22D3EE,
  success: 0x2ECC71,
  danger: 0xED4245,
  gold: 0xF1C75B,
  dark: 0x171A24,
};

// Higher rank is positioned above lower rank after creation.
const roles = [
  { key: 'founder', name: 'Founder', color: 0xF1C75B, hoist: true, rank: 100, permissions: [] },
  { key: 'lead_dev', name: 'Lead Developer', color: 0xA855F7, hoist: true, rank: 90, permissions: [P.ManageMessages, P.ManageThreads] },
  { key: 'developer', name: 'Developer', color: 0x6366F1, hoist: true, rank: 80, permissions: [] },
  { key: 'artist', name: 'Artist', color: 0xEC4899, hoist: true, rank: 75, permissions: [] },
  { key: 'vfx', name: 'VFX Artist', color: 0x22D3EE, hoist: true, rank: 74, permissions: [] },
  { key: 'builder', name: 'Builder', color: 0xF59E0B, hoist: true, rank: 73, permissions: [] },
  { key: 'qa_lead', name: 'QA Lead', color: 0x14B8A6, hoist: true, rank: 70, permissions: [P.ManageMessages, P.ManageThreads] },
  { key: 'head_mod', name: 'Head Moderator', color: 0xDC2626, hoist: true, rank: 65, permissions: [P.ManageMessages, P.ModerateMembers, P.KickMembers] },
  { key: 'moderator', name: 'Moderator', color: 0xEF4444, hoist: true, rank: 60, permissions: [P.ManageMessages, P.ModerateMembers] },
  { key: 'community_manager', name: 'Community Manager', color: 0x10B981, hoist: true, rank: 55, permissions: [P.ManageMessages, P.ManageThreads] },
  { key: 'playtester', name: 'Playtester', color: 0x2DD4BF, hoist: false, rank: 40, permissions: [] },
  { key: 'content_creator', name: 'Content Creator', color: 0xFACC15, hoist: true, rank: 35, permissions: [] },
  { key: 'partner', name: 'Partner', color: 0x38BDF8, hoist: true, rank: 34, permissions: [] },
  { key: 'early_supporter', name: 'Early Supporter', color: 0xF472B6, hoist: false, rank: 30, permissions: [] },

  // Self-assign game roles.
  { key: 'top', name: 'Top', color: 0x94A3B8, hoist: false, rank: 20, permissions: [] },
  { key: 'jungle', name: 'Jungle', color: 0x84CC16, hoist: false, rank: 20, permissions: [] },
  { key: 'mid', name: 'Mid', color: 0xA78BFA, hoist: false, rank: 20, permissions: [] },
  { key: 'adc', name: 'ADC', color: 0xF59E0B, hoist: false, rank: 20, permissions: [] },
  { key: 'support', name: 'Support', color: 0x67E8F9, hoist: false, rank: 20, permissions: [] },

  // Self-assign regions.
  { key: 'region_eu', name: 'EU', color: 0x64748B, hoist: false, rank: 15, permissions: [] },
  { key: 'region_na', name: 'NA', color: 0x64748B, hoist: false, rank: 15, permissions: [] },
  { key: 'region_asia', name: 'Asia', color: 0x64748B, hoist: false, rank: 15, permissions: [] },

  // Self-assign notification roles.
  { key: 'ping_announcements', name: 'Announcements', color: 0x5865F2, hoist: false, rank: 10, permissions: [] },
  { key: 'ping_patch', name: 'Patch Notes', color: 0x5865F2, hoist: false, rank: 10, permissions: [] },
  { key: 'ping_playtest', name: 'Playtest Ping', color: 0x5865F2, hoist: false, rank: 10, permissions: [] },
  { key: 'ping_tournament', name: 'Tournament Ping', color: 0x5865F2, hoist: false, rank: 10, permissions: [] },
];

const staffRoleKeys = ['founder', 'lead_dev', 'head_mod', 'moderator', 'community_manager'];
const devRoleKeys = ['founder', 'lead_dev', 'developer', 'artist', 'vfx', 'builder', 'qa_lead'];
const testerRoleKeys = ['founder', 'lead_dev', 'developer', 'qa_lead', 'playtester'];

const publicChannels = [
  'welcome', 'rules', 'announcements', 'patch-notes', 'sneak-peaks', 'general', 'game-discussion', 'looking-for-team',
];

const rulesText = [
  '**1. Respect everyone.** No harassment, hate speech, threats, targeted insults, or discrimination.',
  '**2. Keep it clean and appropriate.** No NSFW content, scams, malware, or unsafe links.',
  '**3. No spam or disruptive behavior.** Avoid message flooding, excessive pings, mic spam, and channel misuse.',
  '**4. No cheating or exploit distribution.** Do not share executors, cheats, exploits, bypasses, or instructions that damage RFG or Roblox.',
  '**5. Protect privacy.** Never share someone else’s private information, account details, or doxxing material.',
  '**6. Use the right channels.** Bugs go in bug reports, suggestions in suggestions, and support in the support panel.',
  '**7. Staff decisions can be appealed calmly.** Use a private support ticket rather than starting public arguments.',
  '**8. Follow Discord and Roblox rules.** Discord Terms/Guidelines and Roblox Community Standards always apply.',
];

module.exports = {
  P,
  brand,
  roles,
  staffRoleKeys,
  devRoleKeys,
  testerRoleKeys,
  publicChannels,
  rulesText,
};
