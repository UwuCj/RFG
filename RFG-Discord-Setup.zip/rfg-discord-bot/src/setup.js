const fs = require('node:fs');
const path = require('node:path');
const {
  ChannelType,
  PermissionsBitField,
  EmbedBuilder,
} = require('discord.js');
const {
  P,
  brand,
  roles,
  staffRoleKeys,
  devRoleKeys,
  testerRoleKeys,
} = require('./config');
const {
  welcomeEmbed,
  rulesEmbed,
  rolesEmbed,
  roleRows,
  supportEmbed,
  supportRows,
} = require('./panels');

const MANAGED_TOPIC = 'RFG Setup Bot • managed';

function findByName(collection, name) {
  return collection.find(x => x.name === name);
}

// Lets a re-run migrate the old emoji-prefixed role names instead of duplicating them.
function cleanRoleName(name) {
  return name.replace(/^[^\p{L}\p{N}]+/u, '').trim();
}

async function ensureRole(guild, def) {
  let role = findByName(guild.roles.cache, def.name) || guild.roles.cache.find(r => cleanRoleName(r.name) === def.name);
  if (!role) {
    role = await guild.roles.create({
      name: def.name,
      color: def.color,
      hoist: def.hoist,
      mentionable: false,
      permissions: def.permissions,
      reason: 'RFG automated server setup',
    });
  } else {
    await role.edit({
      name: def.name,
      color: def.color,
      hoist: def.hoist,
      permissions: def.permissions,
      reason: 'RFG automated server setup sync',
    }).catch(() => {});
  }
  return role;
}

async function ensureCategory(guild, name, permissionOverwrites = undefined, aliases = []) {
  let channel = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && (c.name === name || aliases.includes(c.name)));
  if (!channel) {
    channel = await guild.channels.create({
      name,
      type: ChannelType.GuildCategory,
      permissionOverwrites,
      reason: 'RFG automated server setup',
    });
  } else {
    if (channel.name !== name) await channel.setName(name, 'RFG category migration').catch(() => {});
    if (permissionOverwrites) await channel.permissionOverwrites.set(permissionOverwrites, 'RFG permission sync').catch(() => {});
  }
  return channel;
}

async function ensureChannel(guild, opts) {
  const { name, type, parent, topic, permissionOverwrites, rateLimitPerUser, userLimit } = opts;
  let channel = guild.channels.cache.find(c => c.name === name && c.parentId === parent.id);
  if (!channel) {
    channel = await guild.channels.create({
      name,
      type,
      parent: parent.id,
      topic: [topic, MANAGED_TOPIC].filter(Boolean).join(' • ').slice(0, 1024),
      permissionOverwrites,
      rateLimitPerUser,
      userLimit,
      reason: 'RFG automated server setup',
    });
  } else {
    const edit = {};
    if ('topic' in channel && type !== ChannelType.GuildVoice && type !== ChannelType.GuildCategory) {
      edit.topic = [topic, MANAGED_TOPIC].filter(Boolean).join(' • ').slice(0, 1024);
    }
    if (typeof rateLimitPerUser === 'number' && 'rateLimitPerUser' in channel) edit.rateLimitPerUser = rateLimitPerUser;
    if (typeof userLimit === 'number' && 'userLimit' in channel) edit.userLimit = userLimit;
    if (Object.keys(edit).length) await channel.edit(edit, 'RFG channel sync').catch(() => {});
    if (permissionOverwrites) await channel.permissionOverwrites.set(permissionOverwrites, 'RFG permission sync').catch(() => {});
  }
  return channel;
}

async function ensureForumWithFallback(guild, opts) {
  try {
    return await ensureChannel(guild, { ...opts, type: ChannelType.GuildForum });
  } catch (error) {
    console.warn(`[setup] Forum #${opts.name} failed, falling back to text:`, error.message);
    return ensureChannel(guild, { ...opts, type: ChannelType.GuildText });
  }
}

function privateOverwrites(guild, roleMap, roleKeys) {
  return [
    { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
    ...roleKeys.map(key => ({
      id: roleMap[key].id,
      allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.Connect, P.Speak],
    })),
  ];
}

function readOnlyOverwrites(guild, roleMap) {
  return [
    { id: guild.roles.everyone.id, allow: [P.ViewChannel, P.ReadMessageHistory], deny: [P.SendMessages] },
    ...staffRoleKeys.map(key => ({
      id: roleMap[key].id,
      allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.ManageMessages],
    })),
  ];
}

function assetPath(file) {
  return path.join(__dirname, '..', 'assets', file);
}

function attachment(file) {
  return { attachment: assetPath(file), name: file };
}

async function ensureWebhook(channel, name = 'RFG Dispatch') {
  const hooks = await channel.fetchWebhooks().catch(() => null);
  let hook = hooks?.find(h => h.owner?.id === channel.client.user.id && h.name === name);
  if (!hook) {
    const avatar = fs.existsSync(assetPath('icon.png')) ? fs.readFileSync(assetPath('icon.png')) : undefined;
    hook = await channel.createWebhook({
      name,
      avatar,
      reason: 'RFG branded starter messages',
    });
  }
  return hook;
}

function addSeedFooters(payload, key) {
  const embeds = (payload.embeds || []).map(embed => {
    const data = EmbedBuilder.from(embed);
    const old = data.data.footer?.text;
    data.setFooter({ text: [old, `seed:${key}`].filter(Boolean).join(' • ') });
    return data;
  });
  return { ...payload, embeds };
}

async function seedOnce(channel, key, payload, opts = {}) {
  if (!channel?.isTextBased()) return;
  const recent = await channel.messages.fetch({ limit: 50 }).catch(() => null);
  if (recent?.some(m => m.embeds.some(e => e.footer?.text?.includes(`seed:${key}`)))) return;

  const finalPayload = addSeedFooters(payload, key);
  if (opts.viaWebhook) {
    const webhook = await ensureWebhook(channel, opts.webhookName || 'RFG Dispatch').catch(() => null);
    if (webhook) {
      await webhook.send({
        ...finalPayload,
        username: opts.username || 'RFG Dispatch',
        allowedMentions: { parse: [] },
      });
      return;
    }
  }

  await channel.send(finalPayload);
}

function brandedHeader({ title, description, color, banner, fields = [], footer = 'RFG • Official channel header' }) {
  const files = [];
  if (fs.existsSync(assetPath('icon.png'))) files.push(attachment('icon.png'));
  if (banner && fs.existsSync(assetPath(banner))) files.push(attachment(banner));

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: footer });

  if (files.some(f => f.name === 'icon.png')) embed.setThumbnail('attachment://icon.png');
  if (banner && files.some(f => f.name === banner)) embed.setImage(`attachment://${banner}`);
  if (fields.length) embed.addFields(fields);

  return { embeds: [embed], files };
}

function replaceChannelRefs(embed, refs) {
  const e = EmbedBuilder.from(embed);
  let text = e.data.description || '';
  for (const [key, id] of Object.entries(refs)) text = text.replaceAll(`<#${key}>`, `<#${id}>`);
  e.setDescription(text);
  return e;
}

async function setupRFG(guild, actorId) {
  await guild.roles.fetch();
  await guild.channels.fetch();

  const botMember = guild.members.me;
  if (!botMember.permissions.has(P.ManageRoles) || !botMember.permissions.has(P.ManageChannels)) {
    throw new Error('I need Manage Roles and Manage Channels. Re-invite me with the generated invite URL or give the bot Administrator temporarily.');
  }
  const canUseWebhooks = botMember.permissions.has(P.ManageWebhooks);

  const roleMap = {};
  for (const def of roles) roleMap[def.key] = await ensureRole(guild, def);

  // Put functional/team roles in a clean hierarchy beneath the bot.
  const botTop = botMember.roles.highest.position;
  const positionable = roles
    .slice()
    .sort((a, b) => a.rank - b.rank)
    .map((def, index) => ({ role: roleMap[def.key].id, position: Math.max(1, Math.min(botTop - 1, index + 1)) }));
  await guild.roles.setPositions(positionable).catch(err => console.warn('[setup] Role positioning skipped:', err.message));

  // Give the server owner the visual Founder role (the guild owner already has ultimate Discord authority).
  const owner = await guild.fetchOwner().catch(() => null);
  if (owner && roleMap.founder.editable) await owner.roles.add(roleMap.founder, 'RFG server founder').catch(() => {});

  const publicReadOnly = readOnlyOverwrites(guild, roleMap);
  const staffPrivate = privateOverwrites(guild, roleMap, staffRoleKeys);
  const devPrivate = privateOverwrites(guild, roleMap, devRoleKeys);
  const testerPrivate = privateOverwrites(guild, roleMap, testerRoleKeys);

  // Categories
  const start = await ensureCategory(guild, '━━━ ✦ START HERE ✦ ━━━');
  const hub = await ensureCategory(guild, '━━━ ⚔ RFG ━━━', undefined, ['━━━ ⚔ RIFTBOUND ━━━']);
  const competitive = await ensureCategory(guild, '━━━ 🏆 COMPETITIVE ━━━');
  const feedback = await ensureCategory(guild, '━━━ 💡 FEEDBACK ━━━');
  const voice = await ensureCategory(guild, '━━━ 🔊 VOICE ━━━');
  const testing = await ensureCategory(guild, '━━━ 🧪 PLAYTESTING ━━━', testerPrivate);
  const support = await ensureCategory(guild, '━━━ 🎫 SUPPORT ━━━');
  const development = await ensureCategory(guild, '━━━ 🛠 DEVELOPMENT ━━━', devPrivate);
  const staff = await ensureCategory(guild, '━━━ 🛡 STAFF ━━━', staffPrivate);

  // Start here
  const channels = {};
  channels.welcome = await ensureChannel(guild, { name: 'welcome', type: ChannelType.GuildText, parent: start, topic: 'Start here: what RFG is and where to go next.', permissionOverwrites: publicReadOnly });
  channels.rules = await ensureChannel(guild, { name: 'rules', type: ChannelType.GuildText, parent: start, topic: 'Official RFG Discord rules.', permissionOverwrites: publicReadOnly });
  channels.announcements = await ensureChannel(guild, { name: 'announcements', type: ChannelType.GuildText, parent: start, topic: 'Major RFG news, releases, events, and official notices.', permissionOverwrites: publicReadOnly });
  channels['sneak-peaks'] = await ensureChannel(guild, { name: 'sneak-peaks', type: ChannelType.GuildText, parent: start, topic: 'Exclusive previews of upcoming RFG champions, maps, VFX, UI, skins, and development progress.', permissionOverwrites: publicReadOnly });
  channels['patch-notes'] = await ensureChannel(guild, { name: 'patch-notes', type: ChannelType.GuildText, parent: start, topic: 'Balance changes, fixes, champion updates, and release notes.', permissionOverwrites: publicReadOnly });
  channels.faq = await ensureChannel(guild, { name: 'faq', type: ChannelType.GuildText, parent: start, topic: 'Frequently asked questions and useful information.', permissionOverwrites: publicReadOnly });
  channels.roles = await ensureChannel(guild, { name: 'roles', type: ChannelType.GuildText, parent: start, topic: 'Choose your lane, region, and notification roles.', permissionOverwrites: publicReadOnly });

  // Main community
  channels.general = await ensureChannel(guild, { name: 'general', type: ChannelType.GuildText, parent: hub, topic: 'Main RFG community chat.', rateLimitPerUser: 2 });
  channels['game-discussion'] = await ensureChannel(guild, { name: 'game-discussion', type: ChannelType.GuildText, parent: hub, topic: 'Talk champions, mechanics, maps, items, and meta.', rateLimitPerUser: 2 });
  channels['builds-strategy'] = await ensureForumWithFallback(guild, { name: 'builds-strategy', parent: hub, topic: 'Long-form champion builds, guides, theorycrafting, and strategy.' });
  channels['clips-media'] = await ensureChannel(guild, { name: 'clips-media', type: ChannelType.GuildText, parent: hub, topic: 'Gameplay clips, screenshots, fan art, edits, and community media.', rateLimitPerUser: 5 });
  channels['looking-for-team'] = await ensureForumWithFallback(guild, { name: 'looking-for-team', parent: hub, topic: 'Find duo partners, squads, scrims, and teammates. Include region and role.' });
  channels.questions = await ensureForumWithFallback(guild, { name: 'questions', parent: hub, topic: 'Ask gameplay and community questions without them getting buried.' });

  // Competitive
  channels.ranked = await ensureChannel(guild, { name: 'ranked', type: ChannelType.GuildText, parent: competitive, topic: 'Ranked discussion, climbing, and competitive play.', rateLimitPerUser: 3 });
  channels.tournaments = await ensureChannel(guild, { name: 'tournaments', type: ChannelType.GuildText, parent: competitive, topic: 'Official and community tournament announcements.', permissionOverwrites: publicReadOnly });
  channels['team-recruitment'] = await ensureForumWithFallback(guild, { name: 'team-recruitment', parent: competitive, topic: 'Recruit players or look for a long-term competitive team.' });

  // Feedback
  channels.suggestions = await ensureForumWithFallback(guild, { name: 'suggestions', parent: feedback, topic: 'One suggestion per post. Explain the problem and your proposed solution.' });
  channels['bug-reports'] = await ensureForumWithFallback(guild, { name: 'bug-reports', parent: feedback, topic: 'Report reproducible RFG bugs. Include steps, device, and screenshots/video when possible.' });
  channels['balance-feedback'] = await ensureForumWithFallback(guild, { name: 'balance-feedback', parent: feedback, topic: 'Structured champion, item, and systems balance feedback.' });

  // Public voice
  await ensureChannel(guild, { name: '🔊 Lobby', type: ChannelType.GuildVoice, parent: voice, userLimit: 0 });
  await ensureChannel(guild, { name: '⚔ Duo Queue', type: ChannelType.GuildVoice, parent: voice, userLimit: 2 });
  await ensureChannel(guild, { name: '🌀 Team 1', type: ChannelType.GuildVoice, parent: voice, userLimit: 5 });
  await ensureChannel(guild, { name: '🌀 Team 2', type: ChannelType.GuildVoice, parent: voice, userLimit: 5 });
  await ensureChannel(guild, { name: '🏆 Competitive', type: ChannelType.GuildVoice, parent: voice, userLimit: 10 });
  await ensureChannel(guild, { name: '💤 AFK', type: ChannelType.GuildVoice, parent: voice, userLimit: 0 });

  // Playtesting
  channels['tester-news'] = await ensureChannel(guild, { name: 'tester-news', type: ChannelType.GuildText, parent: testing, topic: 'Private playtest announcements and test instructions.', permissionOverwrites: testerPrivate });
  channels['test-builds'] = await ensureChannel(guild, { name: 'test-builds', type: ChannelType.GuildText, parent: testing, topic: 'Private build links/codes and test-session information.', permissionOverwrites: testerPrivate });
  channels['test-chat'] = await ensureChannel(guild, { name: 'test-chat', type: ChannelType.GuildText, parent: testing, topic: 'Playtester discussion.', permissionOverwrites: testerPrivate });
  channels['test-bugs'] = await ensureForumWithFallback(guild, { name: 'test-bugs', parent: testing, topic: 'Private test-build bug reports.', permissionOverwrites: testerPrivate });
  await ensureChannel(guild, { name: '🧪 Test Voice', type: ChannelType.GuildVoice, parent: testing, permissionOverwrites: testerPrivate, userLimit: 10 });

  // Support panel + dynamically-created tickets
  channels.support = await ensureChannel(guild, { name: 'support', type: ChannelType.GuildText, parent: support, topic: 'Open a private support or player-report ticket.', permissionOverwrites: publicReadOnly });
  channels['ticket-log'] = await ensureChannel(guild, { name: 'ticket-log', type: ChannelType.GuildText, parent: staff, topic: 'Ticket open/close audit log.', permissionOverwrites: staffPrivate });

  // Development
  channels['dev-chat'] = await ensureChannel(guild, { name: 'dev-chat', type: ChannelType.GuildText, parent: development, topic: 'Private RFG development discussion.', permissionOverwrites: devPrivate });
  channels['dev-updates'] = await ensureChannel(guild, { name: 'dev-updates', type: ChannelType.GuildText, parent: development, topic: 'Internal development progress and handoffs.', permissionOverwrites: devPrivate });
  channels['assets-review'] = await ensureForumWithFallback(guild, { name: 'assets-review', parent: development, topic: 'Review models, VFX, UI, animations, audio, and visual assets.', permissionOverwrites: devPrivate });
  channels['qa-notes'] = await ensureForumWithFallback(guild, { name: 'qa-notes', parent: development, topic: 'QA findings, regressions, test plans, and verification notes.', permissionOverwrites: devPrivate });
  await ensureChannel(guild, { name: '🛠 Dev Room', type: ChannelType.GuildVoice, parent: development, permissionOverwrites: devPrivate, userLimit: 12 });

  // Staff
  channels['staff-hq'] = await ensureChannel(guild, { name: 'staff-hq', type: ChannelType.GuildText, parent: staff, topic: 'Private moderation and community operations.', permissionOverwrites: staffPrivate });
  channels['mod-log'] = await ensureChannel(guild, { name: 'mod-log', type: ChannelType.GuildText, parent: staff, topic: 'Moderation notes and bot logs.', permissionOverwrites: staffPrivate });
  channels['reports'] = await ensureForumWithFallback(guild, { name: 'reports', parent: staff, topic: 'Internal report review and follow-up.', permissionOverwrites: staffPrivate });
  channels['team-tasks'] = await ensureForumWithFallback(guild, { name: 'team-tasks', parent: staff, topic: 'Internal tasks, owners, progress, and handoffs.', permissionOverwrites: staffPrivate });
  await ensureChannel(guild, { name: '🛡 Staff Room', type: ChannelType.GuildVoice, parent: staff, permissionOverwrites: staffPrivate, userLimit: 15 });

  // Seed polished starter content with branded webhook headers.
  const w = replaceChannelRefs(welcomeEmbed(), {
    RULES_CHANNEL: channels.rules.id,
    ROLES_CHANNEL: channels.roles.id,
    GENERAL_CHANNEL: channels.general.id,
    LFG_CHANNEL: channels['looking-for-team'].id,
  });

  await seedOnce(channels.welcome, 'welcome-header', brandedHeader({
    title: 'Welcome to RFG',
    description: 'The official community for a competitive Roblox MOBA focused on champions, map control, macro, and teamplay. Start here, get your roles, and jump into the Rift.',
    color: brand.accent,
    banner: 'welcome.png',
    fields: [
      { name: 'Start Here', value: `Read ${channels.rules} • Pick roles in ${channels.roles}`, inline: false },
      { name: 'Get Involved', value: `Chat in ${channels.general} • Find teammates in ${channels['looking-for-team']}`, inline: false },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG Dispatch' });
  await seedOnce(channels.welcome, 'welcome-panel', { embeds: [w] });

  await seedOnce(channels.rules, 'rules-header', brandedHeader({
    title: 'RFG Community Rules',
    description: 'A clean, competitive, and welcoming server starts with clear expectations. Read these once before you dive in.',
    color: brand.danger,
    banner: 'rules.png',
    fields: [
      { name: 'Quick Summary', value: 'Respect others • No spam • No cheats or exploit distribution • Protect privacy', inline: false },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG Moderation' });
  await seedOnce(channels.rules, 'rules-panel', { embeds: [rulesEmbed()] });

  await seedOnce(channels.roles, 'roles-header', brandedHeader({
    title: 'Personalize Your Profile',
    description: 'Use the buttons below to select your lane, region, and notification preferences. You can change them any time.',
    color: brand.cyan,
    banner: 'roles.png',
    fields: [
      { name: 'Lane', value: 'Top • Jungle • Mid • ADC • Support', inline: true },
      { name: 'Region', value: 'EU • NA • Asia', inline: true },
      { name: 'Pings', value: 'Announcements • Patch Notes • Playtests • Tournaments', inline: false },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG Identity' });
  await seedOnce(channels.roles, 'roles-panel', { embeds: [rolesEmbed()], components: roleRows() });

  await seedOnce(channels.support, 'support-header', brandedHeader({
    title: 'Support & Reports',
    description: 'Need help, want to appeal something, or need to report behavior privately? Use the ticket panel below.',
    color: brand.accent,
    banner: 'support.png',
    fields: [
      { name: 'Support Ticket', value: 'For general help, questions, account issues, or server concerns.', inline: true },
      { name: 'Player Report', value: 'For private behavior reports with screenshots or clips.', inline: true },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG Support' });
  await seedOnce(channels.support, 'support-panel', { embeds: [supportEmbed()], components: supportRows() });

  await seedOnce(channels.faq, 'faq-header', brandedHeader({
    title: 'Frequently Asked Questions',
    description: 'The fastest way for new members to get oriented without needing to ask the same questions repeatedly.',
    color: brand.accent,
    banner: 'faq.png',
  }), { viaWebhook: canUseWebhooks, username: 'RFG Guide' });
  await seedOnce(channels.faq, 'faq-panel', {
    embeds: [new EmbedBuilder()
      .setColor(brand.accent)
      .setTitle('RFG FAQ')
      .setDescription(
        '**What is RFG?**\nA team-based Roblox MOBA inspired by the depth and pacing of classic lane-based MOBAs, built specifically for Roblox.\n\n' +
        '**Where do I report bugs?**\nUse the bug-reports area. Include reproduction steps and evidence when possible.\n\n' +
        '**How do I become a playtester?**\nPlaytester recruitment will be announced when applications or waves open.\n\n' +
        '**Where can I find teammates?**\nUse looking-for-team and include your region, preferred role, and goal.'
      )]
  });

  await seedOnce(channels.announcements, 'announcements-header', brandedHeader({
    title: 'Official Announcements',
    description: 'Major development news, important launches, events, maintenance notices, and community-wide updates will be posted here.',
    color: brand.gold,
    banner: 'announcements.png',
    fields: [
      { name: 'Tip', value: 'Grab the Announcements notification role in the roles channel if you want pings for important updates.', inline: false },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG News' });

  await seedOnce(channels['sneak-peaks'], 'sneak-peaks-header', brandedHeader({
    title: 'Sneak Peeks',
    description: 'Early looks at upcoming champions, maps, VFX, UI, skins, and work-in-progress content. Details may change before release.',
    color: brand.accent,
    banner: 'sneak-peaks.png',
    fields: [
      { name: 'Expect To See', value: 'Champion kits • UI progress • VFX passes • map art • animation previews', inline: false },
    ],
  }), { viaWebhook: canUseWebhooks, username: 'RFG Sneak Peeks' });

  await seedOnce(channels['patch-notes'], 'patch-header', brandedHeader({
    title: 'Patch Notes',
    description: 'Every meaningful gameplay update gets a clear changelog here: champions, items, systems, fixes, tuning, and known issues.',
    color: brand.cyan,
    banner: 'patch-notes.png',
  }), { viaWebhook: canUseWebhooks, username: 'RFG Patch Notes' });

  await seedOnce(channels['tester-news'], 'tester-header', brandedHeader({
    title: 'Playtesting Hub',
    description: 'This area is private to testers and the development team. Build access, test objectives, and feedback priorities will be posted here.',
    color: brand.success,
    banner: 'playtesting.png',
  }), { viaWebhook: canUseWebhooks, username: 'RFG QA' });

  await seedOnce(channels['dev-chat'], 'dev-header', brandedHeader({
    title: 'Development Space',
    description: 'Private production space for implementation handoffs, reviews, asset discussion, priorities, and internal coordination.',
    color: brand.accent,
    banner: 'development.png',
  }), { viaWebhook: canUseWebhooks, username: 'RFG DevOps' });
  return {
    roleCount: Object.keys(roleMap).length,
    channelCount: Object.keys(channels).length,
    actorId,
    roleMap,
    channels,
  };
}

module.exports = { setupRFG, MANAGED_TOPIC };
