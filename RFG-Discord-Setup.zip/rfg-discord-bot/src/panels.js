const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const { brand, rulesText } = require('./config');

function welcomeEmbed() {
  return new EmbedBuilder()
    .setColor(brand.accent)
    .setTitle('⚔️ Welcome to RFG')
    .setDescription(
      'A competitive Roblox MOBA built around teamplay, champions, skill expression, and the fight for the Rift.\n\n' +
      '**Start here**\n' +
      '• Read <#RULES_CHANNEL>\n' +
      '• Pick your lane, region, and notification roles in <#ROLES_CHANNEL>\n' +
      '• Join the community in <#GENERAL_CHANNEL>\n' +
      '• Find teammates in <#LFG_CHANNEL>\n\n' +
      '*Build your team. Master your champion. Claim the Rift.*'
    )
    .setFooter({ text: 'RFG • Roblox MOBA' });
}

function rulesEmbed() {
  return new EmbedBuilder()
    .setColor(brand.danger)
    .setTitle('📜 RFG Community Rules')
    .setDescription(rulesText.join('\n\n'))
    .setFooter({ text: 'Use common sense. Staff may act on behavior that clearly harms the community.' });
}

function rolesEmbed() {
  return new EmbedBuilder()
    .setColor(brand.cyan)
    .setTitle('🎭 Choose Your Roles')
    .setDescription(
      'Use the buttons below to customize your profile. Pressing a button toggles that role on or off.\n\n' +
      '**Lane** — show what you play.\n' +
      '**Region** — make it easier to find teammates.\n' +
      '**Notifications** — only opt into the pings you actually want.'
    );
}

function roleRows() {
  const roleButton = (id, label, emoji, style = ButtonStyle.Secondary) =>
    new ButtonBuilder().setCustomId(`role:${id}`).setLabel(label).setEmoji(emoji).setStyle(style);

  return [
    new ActionRowBuilder().addComponents(
      roleButton('top', 'Top', '⚔️'),
      roleButton('jungle', 'Jungle', '🌿'),
      roleButton('mid', 'Mid', '🔮'),
      roleButton('adc', 'ADC', '🏹'),
      roleButton('support', 'Support', '🪽'),
    ),
    new ActionRowBuilder().addComponents(
      roleButton('region_eu', 'EU', '🌍'),
      roleButton('region_na', 'NA', '🌎'),
      roleButton('region_asia', 'Asia', '🌏'),
    ),
    new ActionRowBuilder().addComponents(
      roleButton('ping_announcements', 'Announcements', '📢', ButtonStyle.Primary),
      roleButton('ping_patch', 'Patch Notes', '📝', ButtonStyle.Primary),
      roleButton('ping_playtest', 'Playtests', '🧪', ButtonStyle.Primary),
      roleButton('ping_tournament', 'Tournaments', '🏆', ButtonStyle.Primary),
    ),
  ];
}

function supportEmbed() {
  return new EmbedBuilder()
    .setColor(brand.accent)
    .setTitle('🎫 RFG Support')
    .setDescription(
      'Need help or need to report something privately? Open a ticket below.\n\n' +
      '• **Support** — account/server questions or general help\n' +
      '• **Report Player** — private behavior/player reports\n\n' +
      'Please do not open duplicate tickets.'
    );
}

function supportRows() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:support').setLabel('Open Support Ticket').setEmoji('🎫').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ticket:report').setLabel('Report Player').setEmoji('🚨').setStyle(ButtonStyle.Danger),
    ),
  ];
}

function closeTicketRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket:close').setLabel('Close Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );
}

module.exports = {
  welcomeEmbed,
  rulesEmbed,
  rolesEmbed,
  roleRows,
  supportEmbed,
  supportRows,
  closeTicketRow,
};
