@echo off
cd /d "%~dp0"
if not exist .env (
  echo [RFG] Missing .env file.
  echo Copy .env.example to .env and fill in BOT_TOKEN, CLIENT_ID and GUILD_ID.
  pause
  exit /b 1
)
if not exist node_modules (
  echo [RFG] Installing dependencies...
  call npm install
  if errorlevel 1 pause & exit /b 1
)
echo [RFG] Starting bot...
node src/index.js
pause
