# RFG Discord Server Installer

A one-command Discord server builder for **RFG**, a Roblox MOBA.

It creates a polished public community, competitive/LFG areas, playtesting, support tickets, private development/staff spaces, self-assign roles, welcome/rules panels, branded webhook headers with custom banner images, and forum-style feedback channels.

## What it creates

### Roles
Team: Founder, Lead Developer, Developer, Artist, VFX Artist, Builder, QA Lead, Head Moderator, Moderator, Community Manager.

Community: Playtester, Content Creator, Partner, Early Supporter.

Player roles: Top, Jungle, Mid, ADC, Support; EU, NA, Asia.

Notification roles: Announcements, Patch Notes, Playtests, Tournaments.

### Sections
- ✦ START HERE — welcome, rules, announcements, patch notes, FAQ, role picker
- ⚔ RFG — general, game discussion, builds/strategy, media, LFG, questions
- 🏆 COMPETITIVE — ranked, tournaments, team recruitment
- 💡 FEEDBACK — suggestions, bug reports, balance feedback
- 🔊 VOICE — lobby, duo, team rooms, competitive, AFK
- 🧪 PLAYTESTING — private tester news/builds/chat/bugs/voice
- 🎫 SUPPORT — ticket panel with private support/report tickets
- 🛠 DEVELOPMENT — private dev chat/updates/assets/QA/voice
- 🛡 STAFF — private staff HQ/logs/reports/tasks/voice

## Setup (Windows-friendly)

1. Create a Discord Application at the **Discord Developer Portal**.
2. Open **Bot** → create/add the bot → reset/copy its token.
3. **Never send your bot token to anyone.** Put it only in your local `.env` file.
4. In Discord, enable **Developer Mode** (`User Settings → Advanced → Developer Mode`).
5. Right-click your RFG server → **Copy Server ID**.
6. In the Developer Portal, copy the application's **Application ID**.
7. Copy `.env.example` to `.env` and fill in:

```env
BOT_TOKEN=your_bot_token
CLIENT_ID=your_application_id
GUILD_ID=your_server_id
```

8. Install Node.js 18+ (current LTS is recommended).
9. Open a terminal in this folder and run:

```bash
npm install
npm run invite
```

10. Open the printed invite URL, invite the bot to your RFG server, and authorize it.
11. In **Server Settings → Roles**, move the bot's role above the RFG roles it will manage.
12. Start it:

```bash
npm start
```

Or double-click `start.bat`.

13. In Discord run:

```text
/setup-preview
/setup-rfg
```

The installer is designed to be re-runnable and **does not intentionally delete unrelated channels or roles**.

If the bot has **Manage Webhooks**, it also posts beautiful branded first-message headers in key channels using webhooks and bundled banner art. If that permission is missing, it falls back to regular bot messages.

## After the automated setup

For the best newcomer experience, enable **Community** and use Discord's native **Onboarding**. Suggested defaults:

- `#welcome`
- `#rules`
- `#announcements`
- `#general`
- `#game-discussion`
- `#looking-for-team`
- `#questions`

Suggested onboarding questions:

**What role do you play?** Top / Jungle / Mid / ADC / Support

**What region are you in?** EU / NA / Asia

**What notifications do you want?** Announcements / Patch Notes / Playtests / Tournaments

Keep each question short and avoid one huge wall of choices.

## Security notes

- Keep the bot token secret and out of GitHub/Discord screenshots.
- The installer does not grant `Administrator` to staff roles.
- Moderator roles get only moderation permissions they need.
- Development, staff, and playtest areas are hidden from `@everyone`.
- The Founder role is primarily visual; Discord's actual server owner already has owner authority.
- After setup, the bot still needs Manage Roles + Manage Channels for self-roles and ticket creation.

## Hosting

The bot must stay online for role buttons and tickets to keep working. Any Node.js host/VPS works. If you only need the one-time structure and do not want the role/ticket features, you can stop/remove the bot after setup.


## Sneak peeks
The installer creates a public read-only `#sneak-peaks` channel for upcoming champions, maps, VFX, UI, skins, and other work-in-progress previews.

## Branded channel headers
Bundled art is included in the `assets/` folder and is automatically used for first-message channel headers such as `#welcome`, `#rules`, `#roles`, `#support`, `#faq`, `#announcements`, `#sneak-peaks`, `#patch-notes`, `#tester-news`, and `#dev-chat`.
